'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://127.0.0.1:6111"',
  OSS_PATH: '"https://guli-file-191125.oss-cn-beijing.aliyuncs.com"'
}
